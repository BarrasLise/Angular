export class Mission {
    
    constructor(public title:string,
        public description:string,
        public url:string,
    ){}

}