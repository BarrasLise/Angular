export class Testimonial {
    
    constructor(public message:string,
        public auteur:string,
        ){}

}